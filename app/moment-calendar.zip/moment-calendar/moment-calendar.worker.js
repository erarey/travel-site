self.addEventListener('message', function(event) {
    self.postMessage('hello ' + event.data)
})