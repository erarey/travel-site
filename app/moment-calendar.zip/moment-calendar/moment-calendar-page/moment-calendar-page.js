import template from './moment-calendar-page.html'
//import './moment-calendar-page.css'

export default {
    bindings: {
        month: '<'
    },
    template,
    controllerAs: 'ctrl',
    controller: function ($log, $scope, $q, moment) {
        //let worker = new Worker(require('./moment-calendar.worker.js'))
        //worker.onmessage = (e) => {
            //$log.log('worker onmessage', e)
        //}

        this.$onInit = () => {
            if (!this.month) throw error('mo-cal-page did not receive month')


        }

    }
}