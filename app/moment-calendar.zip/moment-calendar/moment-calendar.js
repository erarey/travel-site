import template from './moment-calendar.html'
import './moment-calendar.css'

export default {
    template,
    controllerAs: 'ctrl',
    controller: function ($log, $scope, $q, $window, moment) {
        //let worker = new Worker(require('./moment-calendar.worker.js'))
        //worker.onmessage = (e) => {
            //$log.log('worker onmessage', e)
        //}

        const MAX_MONTHS = 7;
        const DAYS_BETWEEN_SANITY_CHECK = 365

        this.scaleFactor = 1
        
        this.cachedYearMonths = {}
        
        this.numMonthsToShow = 1
        
        this.focusedYearMonth 

        this.calDates

        this.calReady = false

        this.dateInput = ''

        this.processDateInput = () => {
            let date = moment(this.dateInput, 'YYYYMMDD')
            if (date.isValid() && date._d != 'invalid date') {
                $log.log('isValid!')
                let date2 = angular.copy(date).add(this.numMonthsToShow, 'month')
                this.dateFeedback = undefined
                $q.when(generateCalendar(date, date2)).then((data) => this.setCalDates(data))
            }
            else {
                this.calDates = undefined
                this.dateFeedback = "wtf kind of date is that??"
            }
        }

        this.setCalDates = (x) => this.calDates = x

        this.scrollDates = (vector) => {
            let date = moment(this.dateInput, 'YYYYMMDD')
            if (date.isValid() && date._d != 'invalid date') {

            }
        }

        angular.element($window).on('resize', (event) => {
            $log.log('resize event', event)
            
        })

        this.$postLink = () => {
            $q.when(generateCalendar(moment(), moment().add(this.numMonthsToShow, 'months')))
                .then(data => {$log.log('data was ', data); this.setCalDates(data); this.calReady = true; $log.log('1complete', this.calDates, this.calReady);})
                .catch(err => $log.log('shit, err', err)) // TODO date MUST be from database, do not get local time here!
        }

        //$scope.$on('message', (e) => {
            //$log.log('caught a message!')
            //$log.log(e)
        //})

        const generateCalendar = (startDate, endDate) => {
            //worker.postMessage('Hello')

            let startMoment = moment(startDate)
            let endMoment = moment(endDate)

            if (!startMoment.isValid() || !endMoment.isValid()) {
                throw 'invalid date'
            }

            let monthsBetween = Math.abs(startDate.diff(endDate, "months"))

            let calendar = {}

            for (let x = 0; x < monthsBetween; x++) {
                calendar[startMoment.format('YYYY-MM')] = generateMonth(startMoment)
                startMoment.add(1, "month")
            }

            return Promise.resolve(calendar)
        }

        const generateMonth = (startMoment) => {
            let calArray = []
            
            let runningMoment = startMoment.startOf('month') // first day of start month

            $log.log('1weekday')

            let daysUntilMonthStart = parseInt(startMoment.isoWeekday() % 7)

            startMoment.add(-1*daysUntilMonthStart, 'day')

            while (daysUntilMonthStart > 0) {
                calArray.push({
                     weekday: runningMoment.isoWeekday(),
                     day: runningMoment.format('D'),
                     month: runningMoment.format('M'),
                     year: runningMoment.format('Y')
                }); 
                $log.log('filling calendar', calArray.length+1)
                runningMoment.add(1, 'day')
                daysUntilMonthStart--
            }

            let daysInMonth = startMoment.daysInMonth()



            for (let x = 0; x < daysInMonth; x++) {
                calArray.push({
                     weekday: runningMoment.isoWeekday(),
                     day: runningMoment.format('D'),
                     month: runningMoment.format('M'),
                     year: runningMoment.format('Y')
                 })

                 runningMoment.add(1, 'day')
            }

            $log.log('1calArray returning', calArray)
            return calArray;

        }
    }
}